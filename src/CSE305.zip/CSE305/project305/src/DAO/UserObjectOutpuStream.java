/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

/**
 *
 * @author DELL
 */
public class UserObjectOutpuStream extends ObjectOutputStream {

    public UserObjectOutpuStream() throws IOException {
        super();
    }

    public UserObjectOutpuStream(OutputStream os) throws IOException {
        super(os);
    }

    protected void writeStreamHeader() throws IOException {
        return;
    }
}
