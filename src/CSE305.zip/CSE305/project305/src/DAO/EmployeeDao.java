/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Employee;
import model.ManageEmployee;
import model.ManageDuty;

/**
 *
 * @author DELL
 */
public class EmployeeDao {

    private String pathStr = "C:\\MON HOC\\CSE305\\project305\\DataEmployee";
    private String filenameBackup = "DataEmployeeByText.txt";
    private String pathToFile = pathStr + "\\" + filenameBackup;

    public void createFolderAndFile() {
        // Tạo thư mục nếu chưa tồn tại
        File folder = new File(pathStr);
        if (!folder.exists()) {
            folder.mkdirs();
        }

        // Tạo tệp tin .txt
        File file = new File(pathToFile);
        try {
            if (file.createNewFile()) {
                System.out.println("File created: " + file.getName());
            } else {
                System.out.println("File already exists.");
            }
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

//    public void saveEmployeeByObject(Employee employee) {
//        ObjectOutputStream oos = null;
//        File file = new File(pathToFile);
//        try {
//
//            if (file.length() == 0) {
//                oos = new ObjectOutputStream(new FileOutputStream(pathToFile));
//
//            } else {
//                oos = new UserObjectOutpuStream(new FileOutputStream(pathToFile, true));
//            }
//
//            oos.writeObject(employee);
//            oos.flush();
//
//        } catch (FileNotFoundException ex) {
//            Logger.getLogger(EmployeeDao.class.getName()).log(Level.SEVERE, null, ex);
//
//        } catch (IOException ex) {
//            Logger.getLogger(EmployeeDao.class.getName()).log(Level.SEVERE, null, ex);
//
//        } finally {
//            try {
//                oos.close();
//            } catch (IOException ex) {
//                Logger.getLogger(EmployeeDao.class.getName()).log(Level.SEVERE, null, ex);
//            }
//        }
//
//    }
//    public List<Employee> loadEmployeeByObject() {
//        List<Employee> employeeList = new ArrayList<>();
//
//        FileInputStream fis = null;
//        try {
//            fis = new FileInputStream(pathToFile);
//            ObjectInputStream ois = new ObjectInputStream(fis);
//
//            while (fis.available() > 0) {
//                Object object = ois.readObject();
//                Employee a = (Employee) object;
//                employeeList.add(a);
//            }
//
//        } catch (FileNotFoundException ex) {
//            Logger.getLogger(EmployeeDao.class.getName()).log(Level.SEVERE, null, ex);
//        } catch (IOException ex) {
//            Logger.getLogger(EmployeeDao.class.getName()).log(Level.SEVERE, null, ex);
//        } catch (ClassNotFoundException ex) {
//            Logger.getLogger(EmployeeDao.class.getName()).log(Level.SEVERE, null, ex);
//        } finally {
//            try {
//                fis.close();
//            } catch (IOException ex) {
//                Logger.getLogger(EmployeeDao.class.getName()).log(Level.SEVERE, null, ex);
//            }
//        }
//
//        return employeeList;
//    }
//    public void updateIn4ToFile(Employee updatedEmployee) {
//        List<Employee> employeeList = loadEmployeeByText();
//
//        // Update the employee in the list
//        for (int i = 0; i < employeeList.size(); i++) {
//            Employee employee = employeeList.get(i);
//            if (employee.getId().equals(updatedEmployee.getId())) { // Assuming Employee has a getId() method
//                employee.setAddress(updatedEmployee.getAddress());
//                employee.setFirstName(updatedEmployee.getFirstName());
//                employee.setLastName(updatedEmployee.getLastName());
//                employee.setPhone(updatedEmployee.getPhone());
//                employee.setDob(updatedEmployee.getDob());
//                break;
//            }
//        }
//
//        // Clear the file
//        clearFile();
//
//        // Write updated objects back to the file
//        for (Employee employee : employeeList) {
//            saveEmployeeByText(employee);
//        }
//    }
    public void saveEmployeeByText(Employee employee) {
        FileWriter writer = null;
        try {
            writer = new FileWriter(pathToFile, true);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);

            bufferedWriter.write(employee.toString());
            bufferedWriter.newLine();
            bufferedWriter.flush();
        } catch (IOException ex) {
            Logger.getLogger(EmployeeDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (writer != null) {
                    writer.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(EmployeeDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public List<Employee> loadEmployeeByText() {
        List<Employee> employeeList = new ArrayList<>();

        FileReader reader = null;
        BufferedReader bufferedReader = null;
        try {
            reader = new FileReader(pathToFile);
            bufferedReader = new BufferedReader(reader);

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                // Parse each line to reconstruct Employee object
                // Assuming Employee class has a static method 'parseFromString(String)' to create an Employee from string
                Employee employee = Employee.parseFromString(line);
                employeeList.add(employee);
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(EmployeeDao.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(EmployeeDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(EmployeeDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        return employeeList;
    }

    public void setEmployeeToFile(Employee employeeToUpdate) {
        List<Employee> employeeList = loadEmployeeByText();
//        for (int i = 0; i < employeeList.size(); i++) {
//            Employee employee = employeeList.get(i);
//            if (employee.getId().equals(employeeToUpdate.getId())) {
//                // Update the employee's information
//                employeeList.set(i, employeeToUpdate);
//                break; // Stop searching once the employee is found and updated
//            }
//        }
        new ManageEmployee().setEmployee(employeeList, employeeToUpdate);
        // Save the updated employee list back to the file
        clearFile(); // Clear the file before rewriting
        for (Employee employee : employeeList) {
            saveEmployeeByText(employee);
        }
    }

    public void updateIn4ToFile(Employee employeeToUpdate) {
        List<Employee> employeeList = loadEmployeeByText();
        new ManageEmployee().updateIn4(employeeList, employeeToUpdate);
        // Save the updated employee list back to the file
        clearFile(); // Clear the file before rewriting
        for (Employee employee : employeeList) {
            saveEmployeeByText(employee);
        }
    }
      public void updateStateEmpToFile(Employee employeeToUpdate) {
        List<Employee> employeeList = loadEmployeeByText();
        new ManageEmployee().updateState(employeeList, employeeToUpdate);
        // Save the updated employee list back to the file
        clearFile(); // Clear the file before rewriting
        for (Employee employee : employeeList) {
            saveEmployeeByText(employee);
        }
    }

//    public void updateStatusDutiesToFile(String idEmployee, int idSchedule, String chuoi) {
//        List<Employee> employeeList = loadEmployeeByText();
//        new ManageDuty().updateDuties(employeeList, idEmployee, idSchedule, chuoi);
//        clearFile(); // Clear the file before rewriting
//        for (Employee employee : employeeList) {
//            saveEmployeeByText(employee);
//        }
//    }

    public void clearFile() {
        try {
            new FileOutputStream(pathToFile).close();
        } catch (IOException ex) {
            Logger.getLogger(EmployeeDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public boolean checkFile() {
        File file = new File(pathToFile);
        if (file.exists()) {
            return true;
        }
        return false;
    }
}
