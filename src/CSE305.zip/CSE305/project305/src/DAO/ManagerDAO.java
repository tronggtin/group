/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Employee;
import model.Manager;

/**
 *
 * @author DELL
 */
public class ManagerDAO {

    private String pathStr = "C:\\MON HOC\\CSE305\\project305\\DataManager";
    private String filenameBackup = "DataManagerByText.txt";
    private String pathToFile = pathStr + "\\" + filenameBackup;

    public void createFolderAndFile() {
        // Tạo thư mục nếu chưa tồn tại
        File folder = new File(pathStr);
        if (!folder.exists()) {
            folder.mkdirs();
        }

        // Tạo tệp tin .txt
        File file = new File(pathToFile);
        try {
            if (file.createNewFile()) {
                System.out.println("File created: " + file.getName());
            } else {
                System.out.println("File already exists.");
            }
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public void saveManagerByText(Manager manager) {
        FileWriter writer = null;
        try {
            writer = new FileWriter(pathToFile, true);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);

            bufferedWriter.write(manager.toString());
            bufferedWriter.newLine();
            bufferedWriter.flush();
        } catch (IOException ex) {
            Logger.getLogger(EmployeeDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (writer != null) {
                    writer.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(EmployeeDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public List<Manager> loadManagerByText() {
        List<Manager> listManagers = new ArrayList<>();

        FileReader reader = null;
        BufferedReader bufferedReader = null;
        try {
            reader = new FileReader(pathToFile);
            bufferedReader = new BufferedReader(reader);

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                // Parse each line to reconstruct Employee object
                // Assuming Employee class has a static method 'parseFromString(String)' to create an Employee from string
                Manager manager = Manager.parseFromString(line);
                listManagers .add(manager);
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(EmployeeDao.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(EmployeeDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(EmployeeDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        return listManagers;
    }

    public boolean checkFile() {
        File file = new File(pathToFile);
        if (file.exists()) {
            return true;
        }
        return false;
    }
}
