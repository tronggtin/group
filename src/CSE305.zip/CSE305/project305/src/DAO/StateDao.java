/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Employee;
import model.ManageDuty;
import model.State;

/**
 *
 * @author DELL
 */
public class StateDao {

    private String pathStr = "C:\\MON HOC\\CSE305\\project305\\DataState";
    private String filenameBackup = "DataStateByText.txt";
    private String pathToFile = pathStr + "\\" + filenameBackup;

    public void createFolderAndFile() {
        // Tạo thư mục nếu chưa tồn tại
        File folder = new File(pathStr);
        if (!folder.exists()) {
            folder.mkdirs();
        }

        // Tạo tệp tin .txt
        File file = new File(pathToFile);
        try {
            if (file.createNewFile()) {
                System.out.println("File created: " + file.getName());
            } else {
                System.out.println("File already exists.");
            }
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public void saveStateByText(Map<String, State> employeeStates) {
        FileWriter writer = null;
        BufferedWriter bufferedWriter = null;
        try {
            writer = new FileWriter(pathToFile, true);
            bufferedWriter = new BufferedWriter(writer);

            for (Map.Entry<String, State> entry : employeeStates.entrySet()) {
                String employeeId = entry.getKey();
                State state = entry.getValue();
                bufferedWriter.write(employeeId + "," + state.toString());
                bufferedWriter.newLine();
            }

            bufferedWriter.flush();
        } catch (IOException ex) {
            Logger.getLogger(EmployeeDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (bufferedWriter != null) {
                    bufferedWriter.close();
                }
                if (writer != null) {
                    writer.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(EmployeeDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public List< Map<String, State>> loadStateByText() {

        List< Map<String, State>> list = new ArrayList<>();
        FileReader reader = null;
        BufferedReader bufferedReader = null;
        try {
            reader = new FileReader(pathToFile);
            bufferedReader = new BufferedReader(reader);

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                Map<String, State> employeeStates = new HashMap<>();
                String[] parts = line.split(",");
                String employeeId = parts[0];
                State.RequestType type = State.RequestType.valueOf(parts[1]);
                State.RequestStatus status = State.RequestStatus.valueOf(parts[2]);
                State state = new State(type, status);
                employeeStates.put(employeeId, state);
                list.add(employeeStates);
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(EmployeeDao.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(EmployeeDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(EmployeeDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        return list;
    }

//    public void addOrUpdateEmployeeState(String employeeId, State state, Map<String, State> employeeStates) {
//        employeeStates.put(employeeId, state);
//        saveStateByText(employeeStates);
//    }
    public void updateState(int stt, State newState) {
        List< Map<String, State>> listState = loadStateByText();
        Map<String, State> map = listState.get(stt);
        String employeeId = map.keySet().iterator().next(); // Assuming one entry per map
        map.put(employeeId, newState);

        clearFile(); // Clear the file before rewriting
        for (Map<String, State> employeeState : listState) {
            saveStateByText(employeeState);
        }
    }

    public void clearFile() {
        try {
            new FileOutputStream(pathToFile).close();
        } catch (IOException ex) {
            Logger.getLogger(EmployeeDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public boolean checkFile() {
        File file = new File(pathToFile);
        if (file.exists()) {
            return true;
        }
        return false;
    }
}
