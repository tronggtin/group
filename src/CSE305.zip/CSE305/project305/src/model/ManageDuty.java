/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import DAO.EmployeeDao;

/**
 *
 * @author DELL
 */
public class ManageDuty implements Serializable {
    
    public boolean checkDuties(Employee employee, String placeid, String startTime, String endTime) {
        if (employee == null) {
            return false;
        } else {
            List<Duty> listduty = employee.getDuties();
            for (Duty duty : listduty) {
                String startTimeOld = duty.getStartTime();
                String endTimeOld = duty.getEndTime();
//                String status = duty.getStatus();
                String dutyId = duty.getIdPlace();

//                if (status.equals("refuse")) {
//                    return true;
//                }
                // Kiểm tra nếu IDs khác nhau và trùng thời gian
                if (compareTimes(startTime, startTimeOld) == 0 && compareTimes(endTime, endTimeOld) == 0) {
                    return true;
                }
            }
            return false;
        }
        
    }
    
    public static int compareTimes(String time1, String time2) {
        // Định dạng chuỗi thành đối tượng LocalTime
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("H:mm");
        LocalTime localTime1 = LocalTime.parse(time1, formatter);
        LocalTime localTime2 = LocalTime.parse(time2, formatter);

        // So sánh hai đối tượng LocalTime
        return localTime1.compareTo(localTime2);
    }
    
//    public void updateDuties(List<Employee> employeeList, String idEmployee, int idSchedule, String chuoi) {
//        for (int i = 0; i < employeeList.size(); i++) {
//            Employee employee = employeeList.get(i);
//            if (employee.getId().equals(idEmployee)) {
//                for (Duty duty : employee.getDuties()) {
//                    if (duty.getDutyID() == idSchedule) {
//                        employee.setNumOfDuties(employee.getNumOfDuties() + 1);
//                        duty.setStatus(chuoi);
//                        return;
//                    }
//                }
//            }
//            
//        }
//    }
    
    public void countDuties(Employee employee) {
        for (Duty duty : employee.getDuties()) {
                employee.setNumOfDuties(employee.getNumOfDuties() + 1);
            
        }
    }

//    public void setEmployee(List<Employee> employeeList, Employee employeeToUpdate) {
//        for (int i = 0; i < employeeList.size(); i++) {
//            Employee employee = employeeList.get(i);
//            if (employee.getId().equals(employeeToUpdate.getId())) {
//                // Update the employee's information
//                employeeList.set(i, employeeToUpdate);
//                break; // Stop searching once the employee is found and updated
//            }
//        }
//    }
    //        if (!mapDuties.containsKey(id)) {
    //            return false;
    //        } else {
    //            Duty dutyOld = mapDuties.get(id);
    //            if (dutyOld != null) {
    //                String startTimeOld = dutyOld.getStartTime();
    //                String endTimeOld = dutyOld.getEndTime();
    //                String status = dutyOld.getStatus();
    //                if (status.equals("refuse")) {
    //                    return false;
    //                }
    //                if (compareTimes(startTime, startTimeOld) == 0 && compareTimes(endTime, endTimeOld) == 0) {
    //                    return true;
    //                }
    //            }
    //        }
    //        return false;
}
