/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author DELL
 */
public class ManageState {

    private List<State> states;

    public ManageState() {
        this.states = new ArrayList<>();
    }

    public List<State> getStates() {
        return states;
    }

    public void setStates(List<State> states) {
        this.states = states;
    }

    public String checkState(State state) {
        if (state.getStatus() == State.RequestStatus.APPROVED) {
            return handleApprovedState(state);
        } else if (state.getStatus() == State.RequestStatus.PENDING) {
            return handlePendingState(state);
        } else if (state.getStatus() == State.RequestStatus.DECLINED) {
            return handleDeclinedState(state);
        }
        return "";
    }

    private String handleApprovedState(State state) {
        if (state.getType() == State.RequestType.LEAVE) {
            return "Leave Approved";
        } else if (state.getType() == State.RequestType.OVERDUTY) {
            return "Overduty Approved";
        }
        return "";
    }

    private String handlePendingState(State state) {
        if (state.getType() == State.RequestType.LEAVE) {
            return "Leave Pending";
        } else if (state.getType() == State.RequestType.OVERDUTY) {
            return "Overduty Pending";
        }
        return "";
    }

    private String handleDeclinedState(State state) {
        if (state.getType() == State.RequestType.LEAVE) {
            return "Leave Declined";
        } else if (state.getType() == State.RequestType.OVERDUTY) {
            return "Overduty Declined";
        }
        return "";
    }

//    public void setState(String stt, List<State> list, State stateNew) {
//        list.set(stt, stateNew);
//    }

}
