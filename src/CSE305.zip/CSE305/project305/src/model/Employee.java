/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author DELL
 */
public class Employee implements Serializable {

    private String firstName;
    private String lastName;
    private String dob;
    private String id;
    private String phone;
    private String address;
    private String username;
    private String password;
    private double salary = 0;
    private int absent = 0;
    private State state;
    private List<Duty> duties;

    private int numOfDuties = 0;
    private int maxSize = 12;
    private double salaryPerDay = 70.0;
    private double deductionPerExcessDay = 5.0;

    public Employee(String firstName, String lastName, String dob, String id, String phone, String address) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.dob = dob;
        this.id = id;
        this.phone = phone;
        this.address = address;
        this.state = new State(State.RequestType.NULL, State.RequestStatus.NULL);
        this.duties = new ArrayList<>();

//        this.username = username;
//        this.password = password;
    }

    public void viewDutySchedule() {
        for (Duty duty : duties) {
            System.out.println(duty);
        }
    }

    public int getNumOfDuties() {
        return numOfDuties;
    }

    public void setNumOfDuties(int numOfDuties) {
        this.numOfDuties = numOfDuties;
    }

    public String getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    public String getLastName() {
        return lastName;
    }

    public String getDob() {
        return dob;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public double getSalary() {
        double baseSalary = duties.size() * salaryPerDay; // Tính tổng lương cơ bản

        // Tính số ngày nghỉ vượt quá 3 ngày
        int excessDays = Math.max(0, absent - 3);
        // Tính tổng mức giảm lương dựa trên số ngày nghỉ vượt quá và mức lương cơ bản
        double finalSalary = (1 - (excessDays * deductionPerExcessDay / 100)) * baseSalary;

        return finalSalary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public List<Duty> getDuties() {
        return duties;
    }

    public void setDuties(List<Duty> duties) {
        this.duties = duties;
    }

    public void increaseAbsent() {
        this.absent++;
    }

    public int getAbsent() {
        return absent;
    }

    public void setAbsent(int absent) {
        this.absent = absent;
    }

    public int getMaxSize() {
        return maxSize;
    }

    public void setMaxSize(int maxSize) {
        this.maxSize = maxSize;
    }

    public void increaseMaxSize() {
        this.maxSize++;
    }

    public State getState() {
        return state;
    }

    public void setState(State state) {
        this.state = state;
    }

    public boolean checkNumOfDuties() {
        if (maxSize > duties.size()) {
            return true;
        }
        return false;
    }

    public static Employee parseFromString(String data) {
        // Split the data into employee information and duties
        String[] parts = data.split(",\\[", 2);

        // Split the employee information
        String[] employeeParts = parts[0].split(",");
        if (employeeParts.length < 6) {
            throw new IllegalArgumentException("Invalid employee data: " + data);
        }

        // Create an Employee object
        Employee employee = new Employee(employeeParts[0], employeeParts[1], employeeParts[2], employeeParts[3], employeeParts[4], employeeParts[5]);
        employee.setAbsent(Integer.parseInt(employeeParts[6]));
        employee.setMaxSize(Integer.parseInt(employeeParts[7]));
        employee.setUsername(employeeParts[8]);
        employee.setPassword(employeeParts[9]);
        State.RequestType requestType = State.RequestType.valueOf(employeeParts[10]);
        State.RequestStatus requestStatus = State.RequestStatus.valueOf(employeeParts[11]);
        State state = new State(requestType, requestStatus);
        employee.setState(state);

        if (parts.length > 1) {
            // Remove the closing square bracket if present
            String dutiesPart = parts[1].endsWith("]") ? parts[1].substring(0, parts[1].length() - 1) : parts[1];

            // Split the duty strings
            String[] dutyStrings = dutiesPart.split(", ");

            List<Duty> duties = new ArrayList<>();
            for (String dutyString : dutyStrings) {
                // Remove the opening square bracket if present
                dutyString = dutyString.startsWith("[") ? dutyString.substring(1) : dutyString;
                String[] dutyParts = dutyString.split(",");
                if (dutyParts.length >= 5) {
                    Duty duty = new Duty(Integer.parseInt(dutyParts[0]), dutyParts[1], dutyParts[2], dutyParts[3], dutyParts[4]);
                    duties.add(duty);
                }
            }
            employee.setDuties(duties);
        }

//         Set the state
//        return employee;
        return employee;
    }

    @Override
    public String toString() {
        return firstName + "," + lastName + "," + dob + "," + id + "," + phone + "," + address + "," + absent + "," + maxSize + "," + username + "," + password + "," + state + "," + duties;
    }

}
