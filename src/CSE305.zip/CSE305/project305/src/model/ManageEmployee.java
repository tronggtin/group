/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author DELL
 */
public class ManageEmployee implements Serializable {

    private List<Employee> listEmployee;

    public ManageEmployee() {
        this.listEmployee = new ArrayList<>();

    }

    public void addEmployee(Employee employee) {
        listEmployee.add(employee);
    }

    public void deleteEmployee(Employee employee) {
        listEmployee.remove(employee);
    }

    public Employee findEmployee(String id) {
        for (Employee employee : listEmployee) {
            if (employee.getId().equals(id)) {
                return employee;
            }
        }
        return null;
    }

    public boolean searchEmployeebyID(String id) {
        for (Employee employee : listEmployee) {
            if (employee.getId().equals(id)) {
                return true;
            }
        }
        return false;
    }

    public boolean searchEmployeebyUsername(String username) {
        for (Employee employee : listEmployee) {
            if (employee.getUsername().equals(username)) {
                return true;
            }
        }
        return false;
    }

    public List<Employee> getListEmployee() {
        return listEmployee;
    }

    public void setListEmployee(List<Employee> listEmployee) {
        this.listEmployee = listEmployee;
    }

//    public void editEmployee(Employee newEmployee) {
//
//        Employee oldCus = findEmployee(newEmployee.getId());
//        boolean isTrue = searchEmployeebyID(newEmployee.getId());
//        if (!isTrue) {
//            oldCus.setAddress(newEmployee.getAddress());
//            oldCus.setFirstName(newEmployee.getFirstName());
//            oldCus.setLastName(newEmployee.getLastName());
//            oldCus.setPhone(newEmployee.getPhone());
//            oldCus.setDob(newEmployee.getDob());
//
//        }
//    }
    public List<Employee> findNameEmployeetoSearch(String name) {
        List<Employee> foundList = new ArrayList<>();
        for (Employee employee : this.listEmployee) {
            if (employee.getFirstName().equals(name)) {
                foundList.add(employee);
            }
        }
        return foundList;
    }

    public Employee loginEmployee(String username, String password) {
        for (Employee employee : listEmployee) {
            if (employee.getUsername().equals(username) && employee.getPassword().equals(password)) {
                return employee;
            }
        }
        return null;
    }

    public void updateIn4(List<Employee> employeeList, Employee employeeToUpdate) {
//List<Employee> employeeList = loadEmployeeByText();
        for (Employee employee : employeeList) {
            if (employee.getId().equals(employeeToUpdate.getId())) {
                employee.setAddress(employeeToUpdate.getAddress());
                employee.setFirstName(employeeToUpdate.getFirstName());
                employee.setLastName(employeeToUpdate.getLastName());
                employee.setPhone(employeeToUpdate.getPhone());
                employee.setDob(employeeToUpdate.getDob());
                break;
            }
        }
    }

    public void setEmployee(List<Employee> employeeList, Employee employeeToUpdate) {
        for (int i = 0; i < employeeList.size(); i++) {
            Employee employee = employeeList.get(i);
            if (employee.getId().equals(employeeToUpdate.getId())) {
                // Update the employee's information
                employeeList.set(i, employeeToUpdate);
                break; // Stop searching once the employee is found and updated
            }
        }
    }

    public void updateState(List<Employee> employeeList, Employee employeeToUpdate) {
//List<Employee> employeeList = loadEmployeeByText();
        for (Employee employee : employeeList) {
            if (employee.getId().equals(employeeToUpdate.getId())) {
                employee.getState().setStatus(State.RequestStatus.PENDING);
                employee.getState().setType(State.RequestType.LEAVE);
//                
                break;
            }
        }
    }

}
