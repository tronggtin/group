/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author DELL
 */
public class State {

    public enum RequestType {
        LEAVE,
        OVERDUTY,
        NULL,
    }

    public enum RequestStatus {
        PENDING,
        APPROVED,
        DECLINED,
        NULL,
    }

    private RequestType type;
    private RequestStatus status;

    public State(RequestType type, RequestStatus status) {
        this.type = type;
        this.status = status;
    }

    // Getters and Setters
    public RequestType getType() {
        return type;
    }

    public void setType(RequestType type) {
        this.type = type;
    }

    public RequestStatus getStatus() {
        return status;
    }

    public void setStatus(RequestStatus status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return type + "," + status;
    }
}
