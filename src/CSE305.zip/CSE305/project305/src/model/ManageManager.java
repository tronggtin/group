/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author DELL
 */
public class ManageManager implements Serializable {

    private List<Manager> listManager;
    private List<State> listState;

    public ManageManager() {
        this.listManager = new ArrayList<>();
        this.listState = new ArrayList<>();

    }

    public void addManager(Manager manager) {
        listManager.add(manager);
    }

    public void deleteManager(Manager manager) {
        listManager.remove(manager);
    }

    public Manager findManger(String id) {
        for (Manager manager : listManager) {
            if (manager.getId().equals(id)) {
                return manager;
            }
        }
        return null;
    }

    public boolean searchManagerbyID(String id) {
        for (Manager manager : listManager) {
            if (manager.getId().equals(id)) {
                return true;
            }
        }
        return false;
    }

    public boolean searchManagerbyUsername(String username) {
        for (Manager manager : listManager) {
            if (manager.getUsername().equals(username)) {
                return true;
            }
        }
        return false;
    }

    public List<Manager> getListManager() {
        return listManager;
    }

    public void setListManager(List<Manager> listManager) {
        this.listManager = listManager;
    }

    public void editManager(Manager newManager) {

        Manager oldCus = findManger(newManager.getId());
        boolean isTrue = searchManagerbyID(newManager.getId());
        if (isTrue) {
            oldCus.setAddress(newManager.getAddress());
            oldCus.setFirstName(newManager.getFirstName());
            oldCus.setLastName(newManager.getLastName());
            oldCus.setPhone(newManager.getPhone());
            oldCus.setDob(newManager.getDob());

        }
    }

    public List<Manager> findNameManagertoSearch(String name) {
        List<Manager> foundList = new ArrayList<>();
        for (Manager manager : this.listManager) {
            if (manager.getFirstName().equals(name)) {
                foundList.add(manager);
            }
        }
        return foundList;
    }

    public Manager loginManager(String username, String password) {
        for (Manager manager : listManager) {
            if (manager.getUsername().equals(username) && manager.getPassword().equals(password)) {
                return manager;
            }
        }
        return null;
    }
    
    
     public void addState(State state) {
        listState.add(state);
    }

    public List<State> getListState() {
        return listState;
    }

    public void setListState(List<State> listState) {
        this.listState = listState;
    }
     
}
