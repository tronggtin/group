/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author DELL
 */
public class Manager implements Serializable {

    private String firstName;
    private String lastName;
    private String dob;
    private String id;
    private String phone;
    private String address;
    private String username;
    private String password;

    public Manager(String firstName, String lastName, String dob, String id, String phone, String address) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.dob = dob;
        this.id = id;
        this.phone = phone;
        this.address = address;

//        this.username = username;
//        this.password = password;
    }

    public String getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    public String getLastName() {
        return lastName;
    }

    public String getDob() {
        return dob;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public static Manager parseFromString(String data) {
        // Split the data into employee information and duties
        String[] parts = data.split(",\\[", 2);

        // Split the employee information
        String[] employeeParts = parts[0].split(",");
        if (employeeParts.length < 6) {
            throw new IllegalArgumentException("Invalid employee data: " + data);
        }

        // Create an Employee object
        Manager manager = new Manager(employeeParts[0], employeeParts[1], employeeParts[2], employeeParts[3], employeeParts[4], employeeParts[5]);
        manager.setUsername(employeeParts[6]);
        manager.setPassword(employeeParts[7]);
        return manager;

    }

    @Override
    public String toString() {
        return firstName + "," + lastName + "," + dob + "," + id + "," + phone + "," + address + "," + username + "," + password;
    }

}
